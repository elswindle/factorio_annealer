--[[ Copyright (c) 2017 Optera
 * Part of Logistics Train Network
 *
 * See LICENSE.md in the project directory for license information.
--]]

flib = require('__flib__.data-util')
require ("prototypes.technology")
require ("prototypes.recipes")
require ("prototypes.items")
require ("prototypes.entities")
require ("prototypes.signals")
require ("prototypes.hotkeys")
flib = nil