# Factorio - Inventory Sensor
Factorio mod adding a combinator that reads inventories of wagons, cars, furnaces and more<br/>

Forum: https://forums.factorio.com/viewtopic.php?f=97&t=30454<br/>
Download: https://mods.factorio.com/mods/Optera/Inventory%20Sensor<br/>
